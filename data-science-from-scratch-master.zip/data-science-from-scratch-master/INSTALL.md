# How to Install Python

If you don't already have Python, I strongly recommend you install the Anaconda version,
which includes many of the libraries needed for data science. Get the Python 3 version, not the Python 2 version.

https://www.anaconda.com/distribution/#download-section

Follow the instructions indicated for your platform.
